number= int(input("Enter number between 1-10: "))
if number == 10:
	print("10 9 8 7 6 5 4 3 2 1 0")
elif number == 9:
	print("9 8 7 6 5 4 3 2 1 0")
elif number == 8:
	print("8 7 6 5 4 3 2 1 0")
elif number == 7:
	print("7 6 5 4 3 2 1 0")
elif number == 6:
	print("6 5 4 3 2 1 0")
elif number == 5:
	print("5 4 3 2 1 0")
elif number == 4:
	print("4 3 2 1 0")
elif number == 3:
	print("3 2 1 0")
elif number == 2:
	print("2 1 0")
elif number == 1:
	print("1 0")
else:
	print("0")