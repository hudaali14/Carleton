false=0
while false<3:	
	check= input("It rained today? ")
	if check== "false":
		false= false + 1
	else:
		false=0
print("Quick! Water your garden before all the plants die and you starve to death!")
