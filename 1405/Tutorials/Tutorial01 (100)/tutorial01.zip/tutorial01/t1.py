# my first python program
print("Hello World!")

input("Prompt you want the user to see")
text = input("Type some things: ")
name = input("Enter your name: ")
print(name)

m= 2
x= 3
b=4
y= (m*x)+b
print(y)