Huda Ali 101120387

Source Files: 
- printTriangles.c
- Readme.txt

To compile: gcc -o printTriangles printTriangles.c
To run: ./printTriangles

