int myStrCmp(char *s1, char *s2);
