// myStats.cpp
/* The file consists of the following stats funcions:

 */

#include "stdio.h"
#include "stdlib.h"
 #include "string.h"


#define MAX_EMPLOYEES  200
#define NAME_SIZE     16

struct emp{
    char firstName[NAME_SIZE];
    char familyName[NAME_SIZE];
    float salary;
    float yearsWithCompany;
};

void populateEmployees(struct emp *emp, int numEmployees);

int main(int argc, char* argv[])
{

    struct emp emp[MAX_EMPLOYEES];

    int i;
    int rc;



    populateEmployees(emp, MAX_EMPLOYEES);

	// add code to search for employee against the family name "Carp"

	// if found print the reocrd

	// add code to search for employee against the family name "King"

	// if found print the reocrd


    return 0;
}





/**************************************************************/
/* Purpose: compare the employee reocrd with respect to family name

Input
emp - an employee reocrd
familyName - the key for searching an employee

Output
None

Return
0 if the family name in the employee record does not match that of the given key
1 if the family name in the employee record matches that of the given key
*/

int cmpEmployee(struct emp *emp, char *familyName)

{
  if(myStrCmp(emp ->familyName, familyName)==1){
    return 1;
  }else{
    return 0;
  }
  }
	// add code
	// use the -> opertor to access the fields

	// use your comparison functino to compare the strings

}

struct emp * findEmployee(struct emp *arr, int arraySize, char *familyName){
  for(int i=0; i<arraySize; i++){
    if(myStrCmp(arr[i].familyName, familyName)==1){
      return &arr[i];
    }
  }
  return NULL;
}



/**************************************************************/
/* populates the array of employees

 input
 numEmployees - number of employees
 emp - an array of emplyees

 output
 emp - array of employees

 assumption:
 numEmployees is <= the size of the array emp
 */
#define NUM_NAMES 7
void populateEmployees(struct emp *emp, int numEmployees)
{
    int i=0;
    int j;
    struct emp *empEnd;

    char *fn[NUM_NAMES] = {"John", "Jane", "David", "Dina", "Justin","Jennifer", "Don"};
    char *sn[NUM_NAMES] = {"Smith", "Johnson", "Mart", "Carp", "Farmer","Ouster","Door"};

    empEnd = emp + numEmployees;

    while(emp < empEnd) {
        // get a random value and make sure that it is in the range of 0-30000
        emp->salary = rand() % 30000;
        emp->yearsWithCompany = rand() % 30;
        j = rand() % NUM_NAMES;
        strncpy(emp->firstName, fn[j],NAME_SIZE-1);
        j = rand() % NUM_NAMES;
        strncpy(emp->familyName, sn[j],sizeof(emp->familyName)-1);
        emp++;
    }
}
