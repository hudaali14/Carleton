#include <stdio.h>

// Structure that represents a simple bank account
typedef struct  {
  char  *owner;
  int    accNumber;
  float  balance;
} BankAccountType;

int main() {
  BankAccountType   account;
  
  account.owner = "Rob Banks";
  account.accNumber = 190219;
  account.balance = 2573.81;
  
  printf("%s' account (#", account.owner);
  printf("%d) with ", account.accNumber);
  printf("$%0.2f\n", account.balance);

  BankAccountType   *accPtr = &account;
  printf("account = %p\n", (void *)accPtr);
  printf("accPtr  = %p\n", (void *)&accPtr);

  (*accPtr).owner = "Robin Banks";
  (*accPtr).accNumber = 193248;
  (*accPtr).balance = (*accPtr).balance - 573.00;
  printf("%s' account (#", (*accPtr).owner);
  printf("%d) with ", (*accPtr).accNumber);
  printf("$%0.2f\n", (*accPtr).balance);
  
  accPtr->owner = "Robin Hood";
  accPtr->accNumber = 193249;
  accPtr->balance = accPtr->balance - 200.00;
  printf("%s's account (#", accPtr->owner);
  printf("%d) with ", accPtr->accNumber);
  printf("$%0.2f\n", accPtr->balance);


  return 0;
}