// tw2.cpp : correct the errors/warning in the file.  
//



#include "stdio.h"



int main(int argc, char* argv[])
{
    int x=12;
    
    if(x==3){
	    printf("x is 3\n");
    } else {
        printf("x is not 3\n");
    }
    return 0;
}
