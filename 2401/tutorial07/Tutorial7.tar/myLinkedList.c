#include <stdio.h>
#include <string.h>
#include <stdlib.h>


// define employee structures

#define NAME_LENGTH  16

typedef struct name {
  char firstName[NAME_LENGTH];
  char familyName[NAME_LENGTH];
} Name;

typedef struct emp{
  unsigned int	id;
  float salary;
  Name	name;
} Employee;


// define employee operations

void printEmployee(Employee *emp)
{
	printf("%-16s %-16s %8d  %8.2f \n",
		emp->name.firstName, emp->name.familyName,
		emp->id, emp->salary);

}

void initEmployee(Employee *emp, char *firstName, char *familyName,
	unsigned int id, float salary)
{
	strncpy(emp->name.firstName, firstName, NAME_LENGTH - 1);
	strncpy(emp->name.familyName, familyName, NAME_LENGTH - 1);
	emp->id = id;
	emp->salary = salary;

}

// define linked list structures

typedef struct listNodeStruct ListNode;

struct listNodeStruct {
	Employee *data;
	ListNode *next;	// next node in the linked list
};

// define linked list operations

/***********************************************************/
/*
Purpose:  adds a record as the first node of the linked list
input:
head - head of the list
data - a pointer to an Employee record

Output
head - the updated head of the list

Return
0 - if data was successfully added to the list
1 - if node was not added to the list
*/


int addNode(ListNode **head, Employee *data)
{

	ListNode *p = NULL;
  p = malloc(sizeof(ListNode));
  p-> data= NULL;
  p-> next= NULL;
  p=data;
  p->next= *head;
  head=p;

	// Step 1 allocate memory for the node and initialize all pointers to NULL
    // if an error occured then return 1

	// Step 2 assign the employee record to data

	// Step 3 update the next field of the new node to point to the first node in the list as a "next" node

	// Step 4 update the list head to point to the new node.
    //
    return(0);

}



/***********************************************************/
/*
Purpose:  prints the list from the first node to the last node
input:
head - head of the list

Output
None

Return
None
*/

void printList(ListNode *head)
{
    ListNode* node=head;
    while(node->next!=NULL){
      printEmployee(node->data);
      node= node->next;
    }
    // while list is not empty
        // print the node (using the printEmployee() function)
        // advance to the next node

}


/***********************************************************/
/*
Purpose:  prints the list from the first node to the last node using recursion
input:
head - head of the list

Output
None

Return
None
*/

void printListRecursive(ListNode *head)
{
  if(head!=NULL){
    printEmployee(head->data);
    printListRecursive(head->next);
  }


	// check bounary conditions (list is not empty)

	// do work - print the first node using the function printEmployee()

	// make recursive call with the next node

}




/***********************************************************/
/*
Purpose:  prints the third last record in the list
input:
head - head of the list

Output
None

Return
0 if successful
1 if an error occur (e.g., list does not have three nodes)
*/

int printThirdLast(ListNode *head)

  if(head==NULL || head->next==NULL || head->next->next==NULL){
    return 0;
  }else{
    printEmployee(head->data);
  }
  printThirdLast(head->next);
	// check bounary conditions - here the recursion stops when the
    // third last node record is reached.  Note that the list may
    // not have three nodes

	// if the third last node was reached then print the data

	// else make recursive call
    // return the result of the recursive call
    return(0);

}


/***********************************************************/
/*
Purpose:  prints the list in reverse from the last node to the first node using recursiion
input:
head - head of the list

Output
None

Return
None
*/
void printListInReverse(ListNode *head)
{
  if(head!=NULL){
    printListRecursive(head->next);
    printEmployee(head->data);
  }
	// check bounary conditions

	// make recursive call

	// do work

}




/***********************************************************/
/*
Purpose:  delete the first node from the linked list
input:
head - head of the list

Output
head - the updated head of the list
data - the data that was stroed in the record

Return
none t
*/

void deleteNode(ListNode **head, Employee **data)
{

	ListNode *p = NULL;
  *data = (*head)->data;
  if(head!=NULL){
    data-> data=NULL;
    data-> next= NULL;
  }else{
    p=head;
  }
  *data= p->data;
  head= head->next;
  free(p);
  p=NULL;
	// Step 1
    // if the list is empty then
    //     set data to NULL
    //     return
    // else set p to the point to the first node

	// Step 2 assign the data in the node to the output data

	// Step 3 set the head to point to the next node in the list

	// Step 4 free the node pointed to by p and set p to NULL

}
/***********************************************************/



int main(void) {
  int i;

  Employee employee[5];
  Employee *data = NULL;

  initEmployee(&employee[0], "Joe", "Clark", 567890345,100345);
  initEmployee(&employee[1],"Brian", "Mulroney", 567890767, 178983);
  initEmployee(&employee[2],"Jean", "Chretien", 567345890, 190329);
  initEmployee(&employee[3],"Paul", "Martin", 567899528, 192456);
  initEmployee(&employee[4],"Kim", "Campbell", 567436582, 192234);


  printf("array of employees \n");
  for (i = 0; i < 5; i++) {
	  printEmployee(&employee[i]);
  }

  ListNode *empHead = NULL;

    // add five nodes
  for (i = 0; i < 5; i++) {
	  addNode(&empHead, &employee[i]);
  }

  printf("\n Printing the list from the first node to the last node \n");
  printList(empHead);


  printf("\n Recursive printing of list  \n");
  printListRecursive(empHead);

  printf("\n Reverse printing of list  \n");
  printListInReverse(empHead);

  printf("\n Printing the third last node in the list \n");
  printThirdLast(empHead);

  // delete five nodes
  /*  for (i = 0; i < 5; i++) {
	  deleteNode(&empHead, &data);
      printf("deleted node [%d] \n",i);
	  printEmployee(data);
  }
  */
  printf("\n");
  return 0;
}
