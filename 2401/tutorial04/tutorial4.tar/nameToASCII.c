#include <stdio.h>
#include <string.h>

int main(){
  char name[10];
  printf("Please enter name: \n");
  scanf("%s", name);
  while(getchar()!= '\n');

  int len=strlen(name);

  for(int i=0; i<len; i++){
    int ascii= (int) name[i];
    printf("%c = %d \n", ascii, ascii);
  }
}
