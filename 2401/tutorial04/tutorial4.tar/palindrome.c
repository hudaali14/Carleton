#include<stdio.h>
#include<string.h>

int palindrome(char *s)
{
  int start=0;
  int end= strlen(s)-1;
   while(start<end){
     if(s[start]!=s[end]){
       printf("%s is not a palindrome \n", s);
       return 0;
     }else{
       start++;
       end--;
     }
   }
   printf("%s is a palindrome \n", s);
   return 1;

}


int main() {

  char word[30];


  printf ("Enter a word or \"q\" to stop: ");
  scanf ("%s", word);

  while (strcmp(word, "q") != 0) {
    palindrome(word);
    printf ("Enter a word or \"q\" to stop: ");
    scanf ("%s", word);
  };

  return 0;

}
